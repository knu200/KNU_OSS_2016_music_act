public class MainClass {
	public static GUI window;

	public static void main(String[] args) {
		window = new GUI();

		window.frmLeapInstrument.setVisible(true);

	}

}
