package test;
import test.Window;
public class MusicMain {
	public static Window window;
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		window = new Window();
		window.frame.setVisible(true);
	}

}
